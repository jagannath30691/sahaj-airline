package com.sahaj.airline.util;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("singleton")
public class WriteCsvFile {

	Logger logger = LoggerFactory.getLogger(this.getClass());

	/**
	 * Making the Class singleton since the application is a standalone Parameter
	 * List<T> uses a generic to accept different types of objects to reduce the LoC
	 **/

	public <T> void writeCSV(List<T> data, String headers, String fileName) {

		try (BufferedWriter bw = new BufferedWriter(new FileWriter(fileName))) {
			bw.write(headers);
			bw.newLine();
			for (T item : data) {
				bw.write(item.toString());
				bw.newLine();
			}
			logger.info("File write successfull - {}", fileName);

		} catch (IOException e) {
			logger.error("Error while writing CSV file: " + e.getMessage());
		}
	}

}
