package com.sahaj.airline.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PassengerErrorVo extends PassengerInputVo {

	public PassengerErrorVo(PassengerInputVo passengerInputVo) {
		this.setBookedCabin(passengerInputVo.getBookedCabin());
		this.setEmail(passengerInputVo.getEmail());
		this.setFareClass(passengerInputVo.getFareClass());
		this.setFirstName(passengerInputVo.getFirstName());
		this.setLastName(passengerInputVo.getLastName());
		this.setMobilePhone(passengerInputVo.getMobilePhone());
		this.setPax(passengerInputVo.getPax());
		this.setPnr(passengerInputVo.getPnr());
		this.setTicketingDate(passengerInputVo.getTicketingDate());
		this.setTravelDate(passengerInputVo.getTravelDate());

	}

	private String error = "";

	@Override
	public String toString() {
		return firstName + "," + lastName + "," + Pnr + "," + fareClass + "," + travelDate + "," + pax + ","
				+ ticketingDate + "," + email + "," + mobilePhone + "," + bookedCabin + "," + error;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

}
