package com.sahaj.airline.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.sahaj.airline.model.PassengerInputVo;

@Component
@Scope("singleton")
public class ReadCsvFileUtil {
	Logger logger = LoggerFactory.getLogger(this.getClass());

	// Reading a CSV file and store it in List<Map>
	// Generic way to handle any file
	public List<Map<String, String>> readCSV(String fileName) {
		logger.info("Reading the CSV file " + fileName);
		List<Map<String, String>> rows = new ArrayList<>();
		try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
			String line;
			String[] header = null;
			while ((line = br.readLine()) != null) {
				if (header == null) {
					header = line.split(",");
				} else {
					String[] values = line.split(",");
					Map<String, String> row = new HashMap<>();
					for (int i = 0; i < header.length; i++) {
						row.put(header[i].trim(), values[i].trim());
					}
					rows.add(row);
				}
			}
			logger.info("Read CSV file is completed");
		} catch (Exception e) {
			// e.printStackTrace();
			logger.error("Error while reading CSV file: " + e.getMessage());
		}
		return rows;
	}

	public List<PassengerInputVo> convertToPOJO(List<Map<String, String>> data) {
		List<PassengerInputVo> result = new ArrayList<>();
		logger.info("Assigning the CSV file values to PoJo");

		for (Map<String, String> row : data) {
			PassengerInputVo item = new PassengerInputVo();
			item.setFirstName(row.get("First_Name"));
			item.setLastName(row.get("Last_Name"));
			item.setPnr(row.get("PNR"));
			item.setFareClass(row.get("Fare_class").trim().toCharArray()[0]);

			try {
				item.setTravelDate(new SimpleDateFormat("yyyy-MM-dd").parse(row.get("Travel_date")));
				item.setTicketingDate(new SimpleDateFormat("yyyy-MM-dd").parse(row.get("Ticketing_date")));
			} catch (Exception e) {
				logger.error("Exception on parsing the Date {}", e.getMessage());
				try {
					item.setTravelDate(new SimpleDateFormat("yyyy-MM-dd").parse("2019-06-22"));
					item.setTicketingDate(new SimpleDateFormat("yyyy-MM-dd").parse("2019-08-22"));
				} catch (ParseException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
			item.setPax(Integer.parseInt(row.get("Pax")));
			item.setEmail(row.get("Email"));
			item.setMobilePhone(row.get("Mobile_phone"));
			item.setBookedCabin(row.get("Booked_cabin"));

			result.add(item);
		}
		return result;
	}

}
