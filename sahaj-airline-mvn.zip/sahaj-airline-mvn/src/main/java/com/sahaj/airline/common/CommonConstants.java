package com.sahaj.airline.common;

/**
 * Creating a common class to store the constants to reduce the places if make
 * change in future.
 **/

public class CommonConstants {

	public static String INPUT_FILENAME = "src/main/resources/airline-input.csv";

	public static String DISCOUNT_FILENAME = "src/main/resources/airline-success-out.csv";
	public static String DISCOUNT_FILE_HEADERS = "First_Name,Last_Name,PNR,Fare_class,Travel_date,Pax,Ticketing_date,Email,Mobile_phone,Booked_cabin,Discount_code";

	public static String VALIDATION_FILENAME = "src/main/resources/airline-failed-out.csv";
	public static String VALIDATION_FILE_HEADERS = "First_Name,Last_Name,PNR,Fare_class,Travel_date,Pax,Ticketing_date,Email,Mobile_phone,Booked_cabin,Errors";

	public static String CABIN_ERROR_MESSAGE = " The booked cabin is not valid";
	public static String EMAIL_ERROR_MESSAGE = " Email is not valid";
	public static String MOBILE_ERROR_MESSAGE = " Mobile number is not valid";
	public static String TICKET_DATE_ERROR_MESSAGE = " Ticketing date should before travel date";
	public static String PNR_ERROR_MESSAGE = " PNR is not valid";

	public static String DISCOUNT_A_E = "OFFER_20";
	public static String DISCOUNT_F_K = "OFFER_30";
	public static String DISCOUNT_L_R = "OFFER_25";
	public static String DISCOUNT_OTHERS = "";

	public static final String EMAIL_REGEX = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
	public static final String PHONE_REGEX = "^[0-9]{10}$";
	public static final String PNR_REGEX = "^[a-zA-Z0-9]{6}$";
	public static final String[] ALLOWED_CABINS = { "Economy", "Premium Economy", "Business", "First" };

}
