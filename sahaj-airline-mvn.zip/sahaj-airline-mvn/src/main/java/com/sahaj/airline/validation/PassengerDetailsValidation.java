package com.sahaj.airline.validation;

import java.time.LocalDate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.sahaj.airline.common.CommonConstants;

//● Email ID is valid
//● The mobile phone is valid
//● Ticketing date is before travel date
//● PNR is 6 characters and Is alphanumeric
//● The booked cabin is valid (one of Economy, Premium Economy,Business, First) 

public class PassengerDetailsValidation {

	public static boolean validateEmail(String email) {
		Pattern pattern = Pattern.compile(CommonConstants.EMAIL_REGEX);
		Matcher matcher = pattern.matcher(email);
		return matcher.matches();
	}

	public static boolean validateMobilePhone(String phone) {
		Pattern pattern = Pattern.compile(CommonConstants.PHONE_REGEX);
		Matcher matcher = pattern.matcher(phone);
		return matcher.matches();
	}

	public static boolean validateTicketingDate(LocalDate ticketingDate, LocalDate travelDate) {
		return ticketingDate.isBefore(travelDate);
	}

	public static boolean validatePnr(String pnr) {
		Pattern pattern = Pattern.compile(CommonConstants.PNR_REGEX);
		Matcher matcher = pattern.matcher(pnr);
		return matcher.matches();
	}

	public static boolean validateCabin(String cabin) {
		for (String allowedCabin : CommonConstants.ALLOWED_CABINS) {
			if (cabin.equals(allowedCabin)) {
				return true;
			}
		}
		return false;
	}
}
