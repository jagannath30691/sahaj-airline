package com.sahaj.airline.validation;

import java.time.LocalDate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.sahaj.airline.common.CommonConstants;

public class PassengerDetailsValidation {

	/**
	 * Creating a util class for validation. can be used as a generic validation
	 **/

	public static String validateEmail(String email) {
		Pattern pattern = Pattern.compile(CommonConstants.EMAIL_REGEX);
		Matcher matcher = pattern.matcher(email);
		return matcher.matches() ? "" : CommonConstants.EMAIL_ERROR_MESSAGE;
	}

	public static String validateMobilePhone(String phone) {
		Pattern pattern = Pattern.compile(CommonConstants.PHONE_REGEX);
		Matcher matcher = pattern.matcher(phone);
		return matcher.matches() ? "" : CommonConstants.MOBILE_ERROR_MESSAGE;
	}

	public static String validateTicketingDate(LocalDate ticketingDate, LocalDate travelDate) {
		return ticketingDate.isBefore(travelDate) ? "" : CommonConstants.TICKET_DATE_ERROR_MESSAGE;
	}

	public static String validatePnr(String pnr) {
		Pattern pattern = Pattern.compile(CommonConstants.PNR_REGEX);
		Matcher matcher = pattern.matcher(pnr);
		return matcher.matches() ? "" : CommonConstants.PNR_ERROR_MESSAGE;
	}

	public static String validateCabin(String cabin) {
		for (String allowedCabin : CommonConstants.ALLOWED_CABINS) {
			if (cabin.equals(allowedCabin)) {
				return "";
			}
		}
		return CommonConstants.CABIN_ERROR_MESSAGE;
	}
}
