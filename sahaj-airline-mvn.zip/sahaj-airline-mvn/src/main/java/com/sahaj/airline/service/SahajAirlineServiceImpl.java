package com.sahaj.airline.service;

import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sahaj.airline.common.CommonConstants;
import com.sahaj.airline.model.PassengerErrorVo;
import com.sahaj.airline.model.PassengerInputVo;
import com.sahaj.airline.model.PassengerSuccessVo;
import com.sahaj.airline.util.ReadCsvFileUtil;
import com.sahaj.airline.util.WriteCsvFile;
import com.sahaj.airline.validation.PassengerDetailsValidation;

@Service
public class SahajAirlineServiceImpl implements SahajAirlineService {

	Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	ReadCsvFileUtil readCsvFileUtil;

	@Autowired
	WriteCsvFile writeCsvFile;

	public void validatePassengerAndApplyDiscount() {
		logger.info("Processing the passenger discount offer details STARTED");

		/** Reading the passenger details from File **/
		List<PassengerInputVo> passengersList = readPassengerDetailsFromCsv(CommonConstants.INPUT_FILENAME);

		/**
		 * Validating the passenger details and write it in file airline-failed-out.csv
		 * and store the rest of the passenger details in passengersList
		 **/
		passengersList = validatePassengerDetails(passengersList);

		/**
		 * Applying the discount code to the list of passengers got after the validation
		 * and create a file airline-success-out.csv and still keeps the valid passenger
		 * details in the passengersList
		 **/
		passengersList = applyDiscountCode(passengersList); // Apply discount code and create file

		// **** We can use the passengers list from here for future enhancements ***

		logger.info("Processing the passenger discount offer details COMPLETED");

	}

	// Fare class A - E will have discount code OFFER_20,
	// F - K will have discount code OFFER_30,
	// L - R will have OFFER_25;
	// rest will have no offer code

	private List<PassengerInputVo> applyDiscountCode(List<PassengerInputVo> inputList) {
		logger.info("Start applying discount code for the passengers list after the validation ");
		List<PassengerInputVo> passengersList = new ArrayList<PassengerInputVo>();

		List<PassengerSuccessVo> passengersListWithDiscountCode = new ArrayList<PassengerSuccessVo>();

		for (PassengerInputVo input : inputList) {
			PassengerSuccessVo success = new PassengerSuccessVo(input);
			switch (input.getFareClass()) {
			case 'A':
			case 'B':
			case 'C':
			case 'D':
			case 'E':
				success.setDiscountCode(CommonConstants.DISCOUNT_A_E);
				break;
			case 'F':
			case 'G':
			case 'H':
			case 'I':
			case 'J':
			case 'K':
				success.setDiscountCode(CommonConstants.DISCOUNT_F_K);
				break;
			case 'L':
			case 'M':
			case 'N':
			case 'O':
			case 'P':
			case 'Q':
			case 'R':
				success.setDiscountCode(CommonConstants.DISCOUNT_L_R);
				break;
			default:
				success.setDiscountCode(CommonConstants.DISCOUNT_OTHERS);
			}
			passengersListWithDiscountCode.add(success);
		}

		writeCsvFile.writeCSV(passengersListWithDiscountCode, CommonConstants.DISCOUNT_FILE_HEADERS,
				CommonConstants.DISCOUNT_FILENAME);

		logger.info("Discount code applied successfully and files has been generated ");

		return passengersList;
	}

	private List<PassengerInputVo> readPassengerDetailsFromCsv(String fileName) {

		logger.info("Reading the inut file {} ", fileName);
		List<Map<String, String>> data = readCsvFileUtil.readCSV(fileName);
		List<PassengerInputVo> passengersList = readCsvFileUtil.convertToPOJO(data);
		return passengersList;
	}

	/**
	 * Validating the passenger details and can accept multiple errors also. In file
	 * it will write the validation error message even if it has more than 1 error
	 **/

	// ● Email ID is valid
	// ● The mobile phone is valid
	// ● Ticketing date is before travel date
	// ● PNR is 6 characters and Is alphanumeric
	// ● The booked cabin is valid (one of Economy, Premium Economy,Business, First)
	private List<PassengerInputVo> validatePassengerDetails(List<PassengerInputVo> inputList) {
		List<PassengerErrorVo> passengerDetailsWithErrorList = new ArrayList<PassengerErrorVo>();

		List<PassengerInputVo> passengersListAfterError = new ArrayList<PassengerInputVo>();

		logger.info("Validating the passengers list");

		for (PassengerInputVo input : inputList) {
			PassengerErrorVo passengerErrorVo = new PassengerErrorVo(input);

			StringBuilder errorString = new StringBuilder();

			errorString.append(PassengerDetailsValidation.validateEmail(input.getEmail()));

			errorString.append(PassengerDetailsValidation.validateCabin(input.getBookedCabin()));

			errorString.append(PassengerDetailsValidation.validateMobilePhone(input.getMobilePhone()));

			errorString.append(PassengerDetailsValidation.validateTicketingDate(
					input.getTicketingDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate(),
					input.getTravelDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate()));

			errorString.append(PassengerDetailsValidation.validatePnr(input.getPnr()));

			if (!errorString.toString().isBlank()) {
				logger.info("List of error for passenger {} is {}", passengerErrorVo.getFirstName(),
						errorString.toString());
				passengerErrorVo.setError(errorString.toString());
				passengerDetailsWithErrorList.add(passengerErrorVo);
			} else {
				passengersListAfterError.add(input);
			}

		}

		writeCsvFile.writeCSV(passengerDetailsWithErrorList, CommonConstants.VALIDATION_FILE_HEADERS,
				CommonConstants.VALIDATION_FILENAME);

		return passengersListAfterError;

	}

}
