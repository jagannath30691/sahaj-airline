package com.sahaj.airline.service;

import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sahaj.airline.common.CommonConstants;
import com.sahaj.airline.model.PassengerErrorVo;
import com.sahaj.airline.model.PassengerInputVo;
import com.sahaj.airline.model.PassengerSuccessVo;
import com.sahaj.airline.util.ReadCsvFileUtil;
import com.sahaj.airline.util.WriteCsvFile;
import com.sahaj.airline.validation.PassengerDetailsValidation;

@Service
public class SahajAirlineServiceImpl implements SahajAirlineService {

	Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	ReadCsvFileUtil readCsvFileUtil;

	@Autowired
	WriteCsvFile writeCsvFile;

	public void validatePassengerAndApplyDiscount() {
		logger.info("Processing the passenger discount offer details STARTED");

		List<PassengerInputVo> passengersList = readPassengerDetailsFromCsv(CommonConstants.INPUT_FILENAME);
		// List of passengers from CSV file

		passengersList = validatePassengerDetails(passengersList); // List of passengers after validation

		passengersList = applyDiscountCode(passengersList); // Apply discount code and create file

		// **** We can use the passengers list from here for future enhancements ***

		logger.info("Processing the passenger discount offer details COMPLETED");

	}

	// Fare class A - E will have discount code OFFER_20,
	// F - K will have discount code OFFER_30,
	// L - R will have OFFER_25;
	// rest will have no offer code

	private List<PassengerInputVo> applyDiscountCode(List<PassengerInputVo> inputList) {
		logger.info("Start applying discount code for the passengers list after the validation ");
		List<PassengerInputVo> passengersList = new ArrayList<PassengerInputVo>();

		List<PassengerSuccessVo> passengersListWithDiscountCode = new ArrayList<PassengerSuccessVo>();

		for (PassengerInputVo input : inputList) {
			PassengerSuccessVo success = new PassengerSuccessVo(input);
			switch (input.getFareClass()) {
			case 'A':
			case 'B':
			case 'C':
			case 'D':
			case 'E':
				success.setDiscountCode(CommonConstants.DISCOUNT_A_E);
				break;
			case 'F':
			case 'G':
			case 'H':
			case 'I':
			case 'J':
			case 'K':
				success.setDiscountCode(CommonConstants.DISCOUNT_F_K);
				break;
			case 'L':
			case 'M':
			case 'N':
			case 'O':
			case 'P':
			case 'Q':
			case 'R':
				success.setDiscountCode(CommonConstants.DISCOUNT_L_R);
				break;
			default:
				success.setDiscountCode(CommonConstants.DISCOUNT_OTHERS);
			}
			passengersListWithDiscountCode.add(success);
		}

		writeCsvFile.writeCSV(passengersListWithDiscountCode, CommonConstants.ERR_FILE_HEADERS,
				CommonConstants.ERR_FILENAME);

		logger.info("Discount code applied successfully and files has been generated ");

		return passengersList;
	}

	private List<PassengerInputVo> readPassengerDetailsFromCsv(String fileName) {

		logger.info("Reading the inut file {} ", fileName);
		List<Map<String, String>> data = readCsvFileUtil.readCSV(fileName);
		List<PassengerInputVo> passengersList = readCsvFileUtil.convertToPOJO(data);
		return passengersList;
	}

	private List<PassengerInputVo> validatePassengerDetails(List<PassengerInputVo> inputList) {
		List<PassengerErrorVo> errors = new ArrayList<PassengerErrorVo>();

		List<PassengerInputVo> passengersListAfterError = new ArrayList<PassengerInputVo>();

		for (PassengerInputVo input : inputList) {
			PassengerErrorVo passengerErrorVo = new PassengerErrorVo(input);

			if (!PassengerDetailsValidation.validateCabin(input.getBookedCabin())) {
				passengerErrorVo.setError(passengerErrorVo.getError().isBlank() ? CommonConstants.CABIN_ERROR_MESSAGE
						: passengerErrorVo.getError() + "; " + CommonConstants.CABIN_ERROR_MESSAGE);
			}
			if (!PassengerDetailsValidation.validateEmail(input.getEmail())) {
				passengerErrorVo.setError(passengerErrorVo.getError().isBlank() ? CommonConstants.EMAIL_ERROR_MESSAGE
						: passengerErrorVo.getError() + "; " + CommonConstants.EMAIL_ERROR_MESSAGE);
			}
			if (!PassengerDetailsValidation.validateMobilePhone(input.getMobilePhone())) {
				passengerErrorVo.setError(passengerErrorVo.getError().isBlank() ? CommonConstants.MOBILE_ERROR_MESSAGE
						: passengerErrorVo.getError() + "; " + CommonConstants.MOBILE_ERROR_MESSAGE);
			}
			if (!PassengerDetailsValidation.validateTicketingDate(
					input.getTicketingDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate(),
					input.getTravelDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate())) {
				passengerErrorVo
						.setError(passengerErrorVo.getError().isBlank() ? CommonConstants.TICKET_DATE_ERROR_MESSAGE
								: passengerErrorVo.getError() + "; " + CommonConstants.TICKET_DATE_ERROR_MESSAGE);
			}
			if (!PassengerDetailsValidation.validatePnr(input.getPnr())) {
				passengerErrorVo.setError(passengerErrorVo.getError().isBlank() ? CommonConstants.PNR_ERROR_MESSAGE
						: passengerErrorVo.getError() + "; " + CommonConstants.PNR_ERROR_MESSAGE);
			}

			if (!passengerErrorVo.getError().isBlank()) {
				logger.info("List of error for passenger {} is {}", passengerErrorVo.getFirstName(),
						passengerErrorVo.getError());

				errors.add(passengerErrorVo);
			} else {
				passengersListAfterError.add(input);
			}

		}

		writeCsvFile.writeCSV(errors, CommonConstants.SUCCESS_FILE_HEADERS, CommonConstants.SUCCESS_FILENAME);

		return passengersListAfterError;

	}

}
