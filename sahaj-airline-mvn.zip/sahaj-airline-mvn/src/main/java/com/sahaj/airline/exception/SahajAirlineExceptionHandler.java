package com.sahaj.airline.exception;

public class SahajAirlineExceptionHandler {

	/* Exception Handler class for controller migration */

}
