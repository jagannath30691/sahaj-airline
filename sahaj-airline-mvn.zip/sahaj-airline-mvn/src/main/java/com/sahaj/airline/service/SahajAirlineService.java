package com.sahaj.airline.service;

import org.springframework.stereotype.Service;

@Service
public interface SahajAirlineService {

	public void validatePassengerAndApplyDiscount();

}
