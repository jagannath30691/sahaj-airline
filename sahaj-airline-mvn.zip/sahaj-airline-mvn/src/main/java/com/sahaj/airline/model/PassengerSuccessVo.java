package com.sahaj.airline.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PassengerSuccessVo extends PassengerInputVo {

	public PassengerSuccessVo(PassengerInputVo passengerInputVo) {
		this.setBookedCabin(passengerInputVo.getBookedCabin());
		this.setEmail(passengerInputVo.getEmail());
		this.setFareClass(passengerInputVo.getFareClass());
		this.setFirstName(passengerInputVo.getFirstName());
		this.setLastName(passengerInputVo.getLastName());
		this.setMobilePhone(passengerInputVo.getMobilePhone());
		this.setPax(passengerInputVo.getPax());
		this.setPnr(passengerInputVo.getPnr());
		this.setTicketingDate(passengerInputVo.getTicketingDate());
		this.setTravelDate(passengerInputVo.getTravelDate());

	}

	private String discountCode;

	@Override
	public String toString() {
		return firstName + "," + lastName + "," + Pnr + "," + fareClass + "," + travelDate + "," + pax + ","
				+ ticketingDate + "," + email + "," + mobilePhone + "," + bookedCabin + "," + discountCode;
	}

	public String getDiscountCode() {
		return discountCode;
	}

	public void setDiscountCode(String discountCode) {
		this.discountCode = discountCode;
	}

}
