package com.sahaj.airline.model;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class PassengerInputVo {

	protected String firstName;
	protected String lastName;
	protected String Pnr;
	protected Character fareClass;
	protected Date travelDate;
	protected int pax;
	protected Date ticketingDate;
	protected String email;
	protected String mobilePhone;
	protected String bookedCabin;

	@Override
	public String toString() {
		return firstName + "," + lastName + "," + Pnr + "," + fareClass + "," + travelDate + "," + pax + ","
				+ ticketingDate + "," + email + "," + mobilePhone + "," + bookedCabin;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPnr() {
		return Pnr;
	}

	public void setPnr(String pnr) {
		Pnr = pnr;
	}

	public Character getFareClass() {
		return fareClass;
	}

	public void setFareClass(Character fareClass) {
		this.fareClass = fareClass;
	}

	public Date getTravelDate() {
		return travelDate;
	}

	public void setTravelDate(Date travelDate) {
		this.travelDate = travelDate;
	}

	public int getPax() {
		return pax;
	}

	public void setPax(int pax) {
		this.pax = pax;
	}

	public Date getTicketingDate() {
		return ticketingDate;
	}

	public void setTicketingDate(Date ticketingDate) {
		this.ticketingDate = ticketingDate;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobilePhone() {
		return mobilePhone;
	}

	public void setMobilePhone(String mobilePhone) {
		this.mobilePhone = mobilePhone;
	}

	public String getBookedCabin() {
		return bookedCabin;
	}

	public void setBookedCabin(String bookedCabin) {
		this.bookedCabin = bookedCabin;
	}

}
