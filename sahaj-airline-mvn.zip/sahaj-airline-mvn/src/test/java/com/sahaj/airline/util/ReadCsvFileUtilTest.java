package com.sahaj.airline.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.sahaj.airline.model.PassengerInputVo;

@ExtendWith(SpringExtension.class)
@SpringBootTest
public class ReadCsvFileUtilTest {

	private List<Map<String, String>> data;
	private List<PassengerInputVo> pojoData;
	private String fileName = "src/main/resources/output.csv";
	public String ERR_FILE_HEADERS = "First_Name,Last_Name,PNR,Fare_class,Travel_date,Pax,Ticketing_date,Email,Mobile_phone,Booked_cabin,Discount_code";

	@BeforeEach
	public void setUp() throws Exception {
		data = new ReadCsvFileUtil().readCSV("src/main/resources/airline-input.csv");
		pojoData = new ReadCsvFileUtil().convertToPOJO(data);
	}

	@Test
	public void testReadCSVFileNotFound() throws Exception {
		List<Map<String, String>> dataWrong = new ReadCsvFileUtil().readCSV("input.csv");
		Assert.assertEquals(0, dataWrong.size());

	}

	private static Logger logger = LoggerFactory.getLogger(com.sahaj.airline.util.ReadCsvFileUtil.class);

	@Test
	public void testReadCSVThrowsParsingException() throws Exception {

		List<Map<String, String>> dataWrong = new ReadCsvFileUtil()
				.readCSV("src/main/resources/airline-wrong-input.csv");
		Assert.assertEquals(0, dataWrong.size());

	}

	@Test
	public void testReadCSV() throws Exception {
		Assert.assertEquals(10, data.size());
		Map<String, String> row1 = data.get(0);
		Assert.assertEquals("Abhishek", row1.get("First_Name"));
		Assert.assertEquals("Kumar", row1.get("Last_Name"));
		Assert.assertEquals("ABC123", row1.get("PNR"));
	}

	@Test
	public void testConvertToPOJO() throws Exception {
		Assert.assertEquals(10, pojoData.size());
		PassengerInputVo row1 = pojoData.get(0);
		Assert.assertEquals("Abhishek", row1.getFirstName());
		Assert.assertEquals("Kumar", row1.getLastName());
		Assert.assertEquals("ABC123", row1.getPnr());
	}

	@Test
	public void testWriteCSV() throws Exception {
		new WriteCsvFile().writeCSV(pojoData, ERR_FILE_HEADERS, fileName);
		File file = new File(fileName);
		Assert.assertTrue(file.exists());
		try (BufferedReader br = new BufferedReader(new FileReader(file))) {
			String line = br.readLine();
			Assert.assertEquals(ERR_FILE_HEADERS, line);
			line = br.readLine();
			Assert.assertEquals(pojoData.get(0).toString(), line);

		} finally {
			file.delete();
		}
	}
}
