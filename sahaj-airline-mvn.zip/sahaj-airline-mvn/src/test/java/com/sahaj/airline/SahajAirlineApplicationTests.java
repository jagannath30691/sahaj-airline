package com.sahaj.airline;

import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.Test;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

@SpringBootTest
class SahajAirlineApplicationTests {

	@MockBean
	private ApplicationArguments args;

	@Test
	void run_shouldInvokeMethodOnApplicationRunner() {
		ApplicationRunner runner = new MyApplicationRunner();
		try {
			runner.run(args);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		verify(args).getNonOptionArgs();
	}

	static class MyApplicationRunner implements ApplicationRunner {

		@Override
		public void run(ApplicationArguments args) {
			args.getNonOptionArgs();
		}
	}
}
