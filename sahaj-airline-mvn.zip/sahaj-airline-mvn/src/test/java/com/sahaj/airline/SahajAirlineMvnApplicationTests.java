package com.sahaj.airline;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SahajAirlineMvnApplicationTests {

	@Test
	void contextLoads() {
	}

}
